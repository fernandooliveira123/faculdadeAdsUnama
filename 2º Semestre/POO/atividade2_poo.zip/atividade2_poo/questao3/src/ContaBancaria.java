public class ContaBancaria {    
    private int NumerodaConta;
    private double Saldo;
    public ContaBancaria(int numerodaConta, double saldo) {
        NumerodaConta = numerodaConta;
        Saldo = saldo;
    }
    public void
    
    }


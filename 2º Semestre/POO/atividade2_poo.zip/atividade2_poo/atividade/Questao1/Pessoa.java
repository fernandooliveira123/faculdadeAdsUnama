public class Pessoa {
    public String nome;
    public int idade;

    public Pessoa(int idade, String nome) {
        this.idade = idade;
        this.nome = nome;
    }

    
}
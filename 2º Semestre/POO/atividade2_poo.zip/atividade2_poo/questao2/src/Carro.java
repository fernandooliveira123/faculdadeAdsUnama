public  class Carro {
    private String Marca;
    private int Ano;

    public Carro(int Ano, String Marca) {
        this.Ano = Ano;
        this.Marca = Marca;
    }

    public String getMarca() {
        return this.Marca;
    }

    public int getAno() {
        return this.Ano;
    }

     

}

public class App {
    public static void main(String[] args) throws Exception {
        Carro carro1 = new Carro (2005,"Renault");
        System.out.println ("Modelo: " +carro1.getMarca()+" ano: "+carro1.getAno());
        
    }

}
